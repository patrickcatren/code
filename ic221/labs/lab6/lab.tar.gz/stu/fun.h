#ifndef FUN_H

#define FUN_H

void bang(char * s);

#endif
