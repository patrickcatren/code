#ifndef LIBRARY_H

#define LIBRARY_H

void reverse(char * s);


#endif
