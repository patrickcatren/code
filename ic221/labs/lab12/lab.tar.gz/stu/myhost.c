#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

int main(int argc, char *argv[]){

	struct addrinfo *result;		// to store results
	struct addrinfo *cur_result;    // to store results
	struct addrinfo hints;			// to indicate information we want
	struct sockaddr_in *saddr;		// to reference address (IPv4)
	int s; 							// for error checking
	
	
	//TODO: Complete the lab
	//
	// Outline:
	//   - set up the hints
	//   - perform the getaddrinfo()
	//   - iterate over the results
	//   - print the resolved ip address
	//   - clean up the results with freaddrinfo()
	
}
